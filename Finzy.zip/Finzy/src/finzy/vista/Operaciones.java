package finzy.vista;

import static finzy.vista.Estilos.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Depósito, retiro y transferencia. Retiro y transferencia quedan pendientes de aprobación del tutor. */
public class Operaciones extends JPanel {

    private final CardLayout cards = new CardLayout();
    private final JPanel formas = clear(cards);

    public Operaciones() {
        setLayout(new BorderLayout());
        JPanel c = pagina();
        put(c, encabezado("Operaciones", "Deposita, retira o transfiere tu dinero."), 0);

        JPanel tabs = clear(new FlowLayout(FlowLayout.LEFT, 8, 0));
        Btn[] bs = new Btn[3]; String[] nombres = {"Depósito", "Retiro", "Transferencia"};
        for (int i = 0; i < 3; i++) {
            final int k = i; bs[i] = new Btn(nombres[i], null, INK); tabs.add(bs[i]);
            bs[i].addActionListener(e -> { cards.show(formas, nombres[k]); for (int j = 0; j < 3; j++) activo(bs[j], j == k); });
        }
        for (int j = 0; j < 3; j++) activo(bs[j], j == 0);
        put(c, tabs, 1);

        formas.add(forma("Depósito", new String[]{"Monto", "Cuenta de origen"}, false), "Depósito");
        formas.add(forma("Retiro", new String[]{"Monto", "Motivo"}, true), "Retiro");
        formas.add(forma("Transferencia", new String[]{"Monto", "Destinatario", "Mensaje (opcional)"}, true), "Transferencia");
        put(c, formas, 2);
        rellenar(c, 3);
        add(scroll(c));
    }

    private static void activo(Btn b, boolean sel) { b.style(sel ? PLUM100 : Color.WHITE, sel ? PLUM800 : INK, sel ? PLUM800 : LINE); }

    private Round forma(String titulo, String[] campos, boolean requiereAprobacion) {
        Round r = new Round(Color.WHITE, LINE, 18);
        r.setLayout(new BoxLayout(r, BoxLayout.Y_AXIS)); r.setBorder(new EmptyBorder(26, 30, 26, 30));
        r.add(left(label(titulo.toUpperCase(), Font.BOLD, 10, CORAL_DARK))); r.add(Box.createVerticalStrut(14));
        if (requiereAprobacion) {
            Round aviso = new Round(SOFT_GOLD, null, 12); aviso.setLayout(new BorderLayout());
            aviso.setBorder(new EmptyBorder(10, 14, 10, 14));
            aviso.add(label("⚠ Esta operación queda pendiente de aprobación de tu tutor.", Font.BOLD, 12, new Color(0x8a6300)));
            aviso.setMaximumSize(new Dimension(480, 44));
            r.add(left(aviso)); r.add(Box.createVerticalStrut(16));
        }
        List<JTextField> fields = new ArrayList<>();
        for (String campo : campos) {
            r.add(left(label(campo, Font.BOLD, 12, PLUM950))); r.add(Box.createVerticalStrut(6));
            JTextField f = new JTextField(); styleField(f); f.setMaximumSize(new Dimension(480, 44));
            fields.add(f); r.add(left(f)); r.add(Box.createVerticalStrut(14));
        }
        Btn ok = new Btn("Confirmar " + titulo.toLowerCase(), CORAL, Color.WHITE);
        ok.addActionListener(e -> {
            if (fields.get(0).getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Escribe el monto.", "Finzy", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // TODO: llamar a la capa de lógica con los datos de los campos.
            JOptionPane.showMessageDialog(this, requiereAprobacion
                    ? "Solicitud enviada. Queda pendiente de aprobación de tu tutor."
                    : titulo + " realizado correctamente.", "Finzy", JOptionPane.INFORMATION_MESSAGE);
            for (JTextField f : fields) f.setText("");
        });
        r.add(left(ok));
        return r;
    }
}
