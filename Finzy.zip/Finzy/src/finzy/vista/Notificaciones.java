package finzy.vista;

import static finzy.vista.Estilos.*;
import javax.swing.*;
import java.awt.*;

/** Bandeja de notificaciones. El menor envía feedback; el tutor envía consejos. */
public class Notificaciones extends JPanel {

    private final boolean tutor;

    public Notificaciones(boolean tutor) {
        this.tutor = tutor;
        setLayout(new BorderLayout());
        JPanel c = pagina();
        put(c, encabezado("Notificaciones", "Mantente al día con la actividad."), 0);
        put(c, columns(bandeja(), 1.1, mensaje(), .9), 1);
        rellenar(c, 2);
        add(scroll(c));
    }

    private Round bandeja() {
        Round p = panelWithTitle("BANDEJA", "Recientes");
        String[][] n = tutor
            ? new String[][]{{"!", "Nueva solicitud de retiro", "Hace 10 min", null}, {"↗", "Gasto alto esta semana", "Hace 2 h", null},
                             {"★", "Sofía alcanzó el 85% de una meta", "Ayer", null}, {"✔", "Vinculación aceptada", "Lun", null}}
            : new String[][]{{"✔", "Depósito recibido", "Hace 10 min", null}, {"!", "Solicitud de retiro aprobada", "Hace 2 h", null},
                             {"✎", "Consejo de tu tutor: ahorra antes de gastar", "Ayer", null}, {"★", "¡Meta al 85%!", "Lun", null}};
        // TODO: cargar notificaciones y alertas educativas reales
        JPanel l = clear(new GridLayout(n.length, 1));
        for (String[] x : n) l.add(fila(x[0], x[1], x[2], x[3], MUTED));
        p.add(l, BorderLayout.CENTER);
        return p;
    }

    private Round mensaje() {
        Round p = tutor ? panelWithTitle("CONSEJOS", "Enviar consejo al menor")
                        : panelWithTitle("FEEDBACK", "Cuéntanos qué piensas");
        JTextArea ta = new JTextArea(6, 20);
        ta.setFont(font(Font.PLAIN, 13)); ta.setLineWrap(true); ta.setWrapStyleWord(true);
        ta.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JScrollPane sp = new JScrollPane(ta); sp.setBorder(new RBorder(LINE, 12));
        Btn enviar = new Btn(tutor ? "Enviar consejo" : "Enviar feedback", CORAL, Color.WHITE);
        enviar.addActionListener(e -> {
            if (ta.getText().isBlank()) return;
            // TODO: enviar a la capa de lógica
            JOptionPane.showMessageDialog(this, tutor ? "Consejo enviado." : "¡Gracias por tu opinión!", "Finzy", JOptionPane.INFORMATION_MESSAGE);
            ta.setText("");
        });
        JPanel s = clear(new FlowLayout(FlowLayout.LEFT, 0, 12)); s.add(enviar);
        p.add(sp, BorderLayout.CENTER); p.add(s, BorderLayout.SOUTH);
        return p;
    }
}
