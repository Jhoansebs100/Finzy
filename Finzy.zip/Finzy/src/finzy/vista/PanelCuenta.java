package finzy.vista;

import static finzy.vista.Estilos.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** RF4 datos de cuenta y saldo, RF15 resumen de gasto y ahorro, RF9 extracto completo con filtros. */
public class PanelCuenta extends JPanel {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final String[] COLS = {"Fecha", "Descripción", "Tipo", "Valor"};
    private static final String[][] DATOS = {   // TODO: movimientos reales
            {"06/11/2026", "Cafetería", "Retiro", "-$ 8.500"}, {"05/11/2026", "Mesada", "Depósito", "+$ 120.000"},
            {"02/11/2026", "Libros del colegio", "Transferencia", "-$ 45.000"}, {"30/10/2026", "Premio por meta", "Depósito", "+$ 20.000"},
            {"28/10/2026", "Transferencia a Juan", "Transferencia", "-$ 15.000"}, {"25/10/2026", "Depósito en efectivo", "Depósito", "+$ 50.000"}};

    private final DefaultTableModel modelo = new DefaultTableModel(COLS, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JComboBox<String> tipo = new JComboBox<>(new String[]{"Todos", "Depósito", "Retiro", "Transferencia"});
    private final JTextField desde = new JTextField(8), hasta = new JTextField(8);

    public PanelCuenta() {
        setLayout(new BorderLayout());
        JPanel c = pagina();
        put(c, encabezado("Mi cuenta", "Datos de tu cuenta, resumen y extracto."), 0);
        JPanel st = clear(new GridLayout(1, 3, 14, 0));
        st.add(stat("SALDO", "$ 1.248.500", "Disponible", GREEN_SOFT, GREEN, "$"));
        st.add(stat("N.º DE CUENTA", "•••• 4821", "Cuenta de ahorro", CORAL_SOFT, CORAL_DARK, "#"));
        st.add(stat("ESTADO", "Activa", "Vinculada a tu tutor", PLUM100, PLUM800, "✔"));
        put(c, st, 1);
        put(c, columns(gastos(), 1.1, resumen(), .9), 2);
        put(c, extracto(), 3);
        rellenar(c, 4);
        add(scroll(c));
        filtrar();
    }

    private Round gastos() {
        Round p = panelWithTitle("RESUMEN", "Gastos de la semana");
        p.add(barras(new int[]{40, 65, 30, 80, 55, 95, 45}, new String[]{"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"}, 5), BorderLayout.CENTER);
        return p;
    }

    private Round resumen() {
        Round p = panelWithTitle("ESTE MES", "Gasto y ahorro");
        JPanel l = clear(null); l.setLayout(new BoxLayout(l, BoxLayout.Y_AXIS));
        Object[][] f = {{"Gastado", .38, "$ 310.400 de $ 820.000 de ingresos", CORAL}, {"Ahorrado", .62, "$ 509.600 de $ 820.000 de ingresos", GREEN}};
        for (Object[] x : f) {
            l.add(left(label((String) x[0], Font.BOLD, 13, INK))); l.add(Box.createVerticalStrut(6));
            l.add(left(new Progress((double) x[1], PLUM100, (Color) x[3]))); l.add(Box.createVerticalStrut(4));
            l.add(left(label((String) x[2], Font.PLAIN, 11, MUTED))); l.add(Box.createVerticalStrut(18));
        }
        p.add(l, BorderLayout.CENTER);
        return p;
    }

    private Round extracto() {
        Round p = panelWithTitle("EXTRACTO", "Movimientos");
        JPanel barra = clear(new FlowLayout(FlowLayout.LEFT, 8, 0));
        for (JTextField t : new JTextField[]{desde, hasta}) { t.setFont(font(Font.PLAIN, 12)); t.setBorder(new RBorder(LINE, 10)); }
        barra.add(label("Tipo", Font.BOLD, 11, MUTED)); barra.add(tipo);
        barra.add(label("Desde", Font.BOLD, 11, MUTED)); barra.add(desde);
        barra.add(label("Hasta", Font.BOLD, 11, MUTED)); barra.add(hasta);
        barra.add(label("(dd/mm/aaaa)", Font.PLAIN, 10, MUTED));
        Btn b = new Btn("Filtrar", CORAL, Color.WHITE); b.setBorder(new EmptyBorder(6, 14, 6, 14));
        b.addActionListener(e -> filtrar());
        barra.add(b);

        JTable t = new JTable(modelo);
        t.setRowHeight(34); t.setShowGrid(false); t.setFont(font(Font.PLAIN, 12)); t.setForeground(INK);
        t.getTableHeader().setFont(font(Font.BOLD, 11)); t.getTableHeader().setReorderingAllowed(false);
        t.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                super.getTableCellRendererComponent(tb, v, s, f, r, c);
                setHorizontalAlignment(RIGHT); setFont(font(Font.BOLD, 12));
                setForeground(String.valueOf(v).startsWith("+") ? GREEN : INK);
                return this;
            }
        });
        JScrollPane sp = new JScrollPane(t); sp.setBorder(BorderFactory.createLineBorder(LINE));
        sp.getViewport().setBackground(Color.WHITE); sp.setPreferredSize(new Dimension(300, 240));
        JPanel top = clear(new BorderLayout()); top.setBorder(new EmptyBorder(0, 0, 10, 0)); top.add(barra, BorderLayout.WEST);
        JPanel cuerpo = clear(new BorderLayout()); cuerpo.add(top, BorderLayout.NORTH); cuerpo.add(sp, BorderLayout.CENTER);
        p.add(cuerpo, BorderLayout.CENTER);
        return p;
    }

    private void filtrar() {
        LocalDate d = fecha(desde.getText()), h = fecha(hasta.getText());
        if ((!desde.getText().isBlank() && d == null) || (!hasta.getText().isBlank() && h == null)) {
            JOptionPane.showMessageDialog(this, "Usa el formato dd/mm/aaaa.", "Finzy", JOptionPane.WARNING_MESSAGE);
            return;
        }
        modelo.setRowCount(0);
        for (String[] r : DATOS) {   // TODO: este filtrado debe hacerlo la capa de lógica
            LocalDate f = LocalDate.parse(r[0], FMT);
            boolean ok = (tipo.getSelectedIndex() == 0 || r[2].equals(tipo.getSelectedItem()))
                    && (d == null || !f.isBefore(d)) && (h == null || !f.isAfter(h));
            if (ok) modelo.addRow(r);
        }
    }

    private static LocalDate fecha(String s) {
        try { return s.isBlank() ? null : LocalDate.parse(s.trim(), FMT); } catch (DateTimeParseException e) { return null; }
    }
}
