package finzy.vista;

import static finzy.vista.Estilos.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** RF3: el tutor vincula a un menor de edad. Solo interfaz. */
public class Vinculacion extends JPanel {

    private final JPanel lista = clear(null);

    public Vinculacion() {
        setLayout(new BorderLayout());
        lista.setLayout(new BoxLayout(lista, BoxLayout.Y_AXIS));
        lista.add(fila("☺", "Sofía Ramírez", "sofia@correo.com", "Activo", GREEN));   // TODO: menores reales

        JPanel c = pagina();
        put(c, encabezado("Vinculación", "Conecta tu cuenta con la de un menor de edad."), 0);
        put(c, columns(formulario(), 1, vinculados(), 1), 1);
        rellenar(c, 2);
        add(scroll(c));
    }

    private Round formulario() {
        Round r = new Round(Color.WHITE, LINE, 18);
        r.setLayout(new BoxLayout(r, BoxLayout.Y_AXIS)); r.setBorder(new EmptyBorder(24, 26, 24, 26));
        r.add(left(label("NUEVA VINCULACIÓN", Font.BOLD, 10, CORAL_DARK))); r.add(Box.createVerticalStrut(6));
        r.add(left(label("<html><div style='width:300px'>El menor debe tener una cuenta en Finzy con perfil Menor. "
                + "Recibirá una solicitud que debe aceptar.</div></html>", Font.PLAIN, 12, MUTED)));
        r.add(Box.createVerticalStrut(18));
        r.add(left(label("Correo del menor", Font.BOLD, 12, PLUM950))); r.add(Box.createVerticalStrut(6));
        JTextField correo = new JTextField(); styleField(correo); r.add(left(correo)); r.add(Box.createVerticalStrut(18));
        Btn b = new Btn("Enviar solicitud de vinculación", CORAL, Color.WHITE);
        b.addActionListener(e -> {
            if (correo.getText().isBlank() || !correo.getText().contains("@")) {
                JOptionPane.showMessageDialog(this, "Escribe un correo válido.", "Finzy", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // TODO: capa de lógica (validar que sea menor de edad y crear la vinculación)
            lista.add(fila("☺", correo.getText().split("@")[0], correo.getText(), "Pendiente", new Color(0x8a6300)));
            lista.revalidate(); lista.repaint(); correo.setText("");
        });
        r.add(left(b));
        return r;
    }

    private Round vinculados() {
        Round p = panelWithTitle("MENORES", "Vinculados");
        p.add(lista, BorderLayout.NORTH);
        return p;
    }
}
