package finzy.vista;

import static finzy.vista.Estilos.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** RF10 crear meta, RF11 aportar, RF12 consultar progreso. Datos en memoria solo para la demo. */
public class Metas extends JPanel {

    private final List<Object[]> metas = new ArrayList<>();   // {nombre, actual, objetivo}  TODO: metas reales
    private final JPanel lista = clear(null);

    public Metas() {
        setLayout(new BorderLayout());
        lista.setLayout(new BoxLayout(lista, BoxLayout.Y_AXIS));
        metas.add(new Object[]{"Bicicleta nueva", 620000.0, 1000000.0});
        metas.add(new Object[]{"Viaje de fin de año", 150000.0, 500000.0});
        metas.add(new Object[]{"Audífonos", 170000.0, 200000.0});

        JPanel c = pagina();
        put(c, encabezado("Metas de ahorro", "Crea metas y aporta para alcanzarlas."), 0);
        Round contenedor = panelWithTitle("PROGRESO", "Mis metas");
        contenedor.add(lista, BorderLayout.NORTH);
        put(c, columns(nuevaMeta(), .75, contenedor, 1.25), 1);
        rellenar(c, 2);
        add(scroll(c));
        refrescar();
    }

    private Round nuevaMeta() {
        Round r = new Round(Color.WHITE, LINE, 18);
        r.setLayout(new BoxLayout(r, BoxLayout.Y_AXIS)); r.setBorder(new EmptyBorder(24, 26, 24, 26));
        r.add(left(label("NUEVA META", Font.BOLD, 10, CORAL_DARK))); r.add(Box.createVerticalStrut(16));
        r.add(left(label("Nombre de la meta", Font.BOLD, 12, PLUM950))); r.add(Box.createVerticalStrut(6));
        JTextField nombre = new JTextField(); styleField(nombre); r.add(left(nombre)); r.add(Box.createVerticalStrut(14));
        r.add(left(label("Monto objetivo", Font.BOLD, 12, PLUM950))); r.add(Box.createVerticalStrut(6));
        JTextField monto = new JTextField(); styleField(monto); r.add(left(monto)); r.add(Box.createVerticalStrut(18));
        Btn crear = new Btn("Crear meta", CORAL, Color.WHITE);
        crear.addActionListener(e -> {
            double v = leerMonto(monto.getText());
            if (nombre.getText().isBlank() || v <= 0) { aviso("Escribe un nombre y un monto válido."); return; }
            // TODO: capa de lógica
            metas.add(new Object[]{nombre.getText().trim(), 0.0, v});
            nombre.setText(""); monto.setText(""); refrescar();
        });
        r.add(left(crear));
        return r;
    }

    private void refrescar() {
        lista.removeAll();
        for (Object[] m : metas) lista.add(filaMeta(m));
        lista.revalidate(); lista.repaint();
    }

    private JPanel filaMeta(Object[] m) {
        double act = (double) m[1], obj = (double) m[2];
        JPanel f = clear(new BorderLayout(12, 0));
        f.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, new Color(0xeef2f6)), new EmptyBorder(10, 0, 12, 0)));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 84));
        JPanel t = clear(null); t.setLayout(new BoxLayout(t, BoxLayout.Y_AXIS));
        t.add(left(label((String) m[0], Font.BOLD, 13, INK))); t.add(Box.createVerticalStrut(8));
        t.add(left(new Progress(Math.min(1, act / obj), PLUM100, act >= obj ? GREEN : CORAL))); t.add(Box.createVerticalStrut(5));
        t.add(left(label(String.format("$ %,.0f / $ %,.0f  ·  %d%%", act, obj, (int) (100 * Math.min(1, act / obj))), Font.PLAIN, 11, MUTED)));
        Btn ap = new Btn(act >= obj ? "Lograda ✔" : "Aportar", act >= obj ? null : CORAL, act >= obj ? GREEN : Color.WHITE);
        ap.setFont(font(Font.BOLD, 12)); ap.setBorder(new EmptyBorder(8, 14, 8, 14));
        ap.setEnabled(act < obj);
        ap.addActionListener(e -> aportar(m));
        JPanel w = clear(new GridBagLayout()); w.add(ap);
        f.add(t, BorderLayout.CENTER); f.add(w, BorderLayout.EAST);
        return f;
    }

    private void aportar(Object[] m) {
        String s = JOptionPane.showInputDialog(this, "¿Cuánto quieres aportar a \"" + m[0] + "\"?", "Aportar a meta", JOptionPane.PLAIN_MESSAGE);
        if (s == null) return;
        double v = leerMonto(s);
        if (v <= 0) { aviso("Escribe un monto válido."); return; }
        // TODO: capa de lógica (validar saldo y registrar el aporte)
        m[1] = Math.min((double) m[2], (double) m[1] + v);
        refrescar();
    }

    private static double leerMonto(String s) {
        try { return Double.parseDouble(s.trim().replace(".", "").replace(",", ".")); }
        catch (NumberFormatException e) { return -1; }
    }

    private void aviso(String t) { JOptionPane.showMessageDialog(this, t, "Finzy", JOptionPane.WARNING_MESSAGE); }
}
