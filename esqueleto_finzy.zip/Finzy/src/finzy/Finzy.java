package finzy;

public class Finzy {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
