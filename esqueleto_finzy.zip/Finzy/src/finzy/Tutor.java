package finzy;


public class Tutor extends Usuario{
    Estudiante[] estudiantesVinculados;
    
    public void autorizarTransaccion(){
        
    }
    public void generarNotificacion(){
        
    }
}
